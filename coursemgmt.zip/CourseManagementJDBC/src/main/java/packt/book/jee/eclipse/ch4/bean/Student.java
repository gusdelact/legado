package packt.book.jee.eclipse.ch4.bean;

public class Student extends Person {
	private long enrolledsince;

	public long getEnrolledsince() {
		return enrolledsince;
	}

	public void setEnrolledsince(long enrolledsince) {
		this.enrolledsince = enrolledsince;
	}
}
